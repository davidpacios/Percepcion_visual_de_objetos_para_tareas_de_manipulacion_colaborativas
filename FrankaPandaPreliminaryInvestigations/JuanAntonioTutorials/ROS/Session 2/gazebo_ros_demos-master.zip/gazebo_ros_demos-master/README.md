# gazebo_ros_demos
* Author: Dave Coleman <davetcoleman@gmail.com>
* License: GNU General Public License, version 3 (GPL-3.0)
* Inception Date: 4 June 2013
* Version: 1.0.0

Example robots and code for interfacing Gazebo with ROS

## Documentation and Tutorials
[On gazebosim.org](http://gazebosim.org/tutorials?cat=connect_ros)

## Develop and Contribute

We welcome any contributions to this repo and encourage you to fork the project then send pull requests back to this parent repo. Thanks for your help!



